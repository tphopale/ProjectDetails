Read Me:
1)	The Emailed attachment has total four files including README.docx
2)	The NewsWhip.zip has executable Jar file for next release of NewsWhip core product.
3)	The ProjectCode.zip consists actual code.
4)	The Assumption&TestResults contains the basic assumptions made during the projects and the testing code as unit test cases.
5) 	To execute project, unzip NewsWhip.zip file and extract Project.jar at suitable location.
6) 	Open the command prompt and reach out to the desired location where Jar is placed.
7) 	Command for execution for the jar as follows:
		java -jar Project.jar "arg1" "arg2" "arg3".....

NOTE: In this case the "arg..." are the command arguments which need to be execute. For example:
	

	java -jar Project.jar "ADD https://www.rte.ie/news/politics/2018/1004/1001034-cso/ 20" "ADD https://www.rte.ie/news/ulster/2018/1004/1000952-moanghan-mine/ 30" "ADD http://www.bbc.com/news/world-europe-45746837 10" "EXPORT" "REMOVE https://www.rte.ie/news/ulster/2018/1004/1000952-moanghan-mine/" "EXPORT"
	java -jar Project.jar "ADD https://www.rte.ie/news/politics/2018/1004/1001034-cso/ 20" "ADD https://www.rte.ie/news/ulster/2018/1004/1000952-moanghan-mine/ 30" "ADD http://www.bbc.com/news/world-europe-45746837 10" "EXPORT" "REMOVE https://www.rte.ie/news/ulster/2018/1004/1000952-moanghan-mine/" "EXPORT" "REMOVE https://www.rte.ie/news/politics/2018/1004/1001034-cso/" "EXPORT"

